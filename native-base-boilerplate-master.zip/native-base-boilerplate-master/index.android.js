import { AppRegistry } from "react-native";
import NativeBaseBoilerplate from "./js/App";

AppRegistry.registerComponent(
  "NativeBaseBoilerplate",
  () => NativeBaseBoilerplate
);
