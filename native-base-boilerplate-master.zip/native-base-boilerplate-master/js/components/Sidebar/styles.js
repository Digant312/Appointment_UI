const styles = {
  image: {
    width: 180,
    height: 180,
    alignSelf: "center",
    marginTop: 40,
    resizeMode: "center"
  }
};

export default styles;
