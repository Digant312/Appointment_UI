const styles = {
  container: {
    backgroundColor: "#fff"
  },
  logo: {
    alignSelf: "center"
  },
  form: {
    paddingRight: 45,
    paddingLeft: 35,
    top: -20
  },
  button: {
    marginTop: 25,
    marginLeft: 15
  }
};

export default styles;
