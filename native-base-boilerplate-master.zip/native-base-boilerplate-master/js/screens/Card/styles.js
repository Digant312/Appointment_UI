const styles = {};

export default styles;
