const styles = {
  h3: {
    marginBottom: 5
  },
  text: {
    fontSize: 16,
    lineHeight: 20
  },
  image: {
    width: 220,
    height: 220,
    alignSelf: "center",
    marginTop: 40
  }
};

export default styles;
